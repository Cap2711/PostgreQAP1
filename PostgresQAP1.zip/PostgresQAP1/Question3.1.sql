
SELECT film_id, title, release_year, rental_rate
FROM film
WHERE release_year = 2006;

SELECT release_year, COUNT(*) AS film_count
FROM film
GROUP BY release_year;

SELECT film_id, title, release_year, rental_rate
FROM film
ORDER BY release_year DESC;

SELECT f.title, f.description, l.name AS language
FROM film f
JOIN language l ON f.language_id = l.language_id;

INSERT INTO customer (customer_id, store_id, first_name, last_name, email, address_id, activebool, create_date, last_update, active)
VALUES
(604, 1, 'Chelsey', 'Penton', 'chelsey.penton@example.com', 400, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1),
(605, 1, 'Marcus', 'Penton', 'marcus.penton@example.com', 400, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1),
(606, 1, 'Carly', 'Penton', 'carly.penton@example.com', 400, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1),
(607, 1, 'Dona', 'Penton', 'dona.penton@example.com', 400, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1);


SELECT * FROM customer WHERE last_name = 'Penton';











