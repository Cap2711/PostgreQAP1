
SELECT film_id, title, release_year, rental_rate
FROM film
WHERE release_year = 2006;

SELECT release_year, COUNT(*) AS film_count
FROM film
GROUP BY release_year;
